from fixtures import checker_game, black_pieces, white_pieces, black_squares
